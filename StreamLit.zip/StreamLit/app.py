import streamlit as st
import pandas as pd
import plotly.express as px
from plotting.vizual_functions import *

if 'data_loaded' not in st.session_state:
    st.session_state['data_loaded'] = False

predict_df = pd.read_csv("predict/probabilities.csv")
predict_df = predict_df.drop(labels="Unnamed: 0", axis=1)
predict_df = predict_df.rename({"через сколько вероятнее уйдет": "Через сколько вероятнее всего уйдет"}, axis=1)
df_interest = pd.read_csv("data/df_interest.csv")
df_mc = pd.read_csv("data/df_mc.csv")
df_price = pd.read_csv("data/df_price.csv")
df_req = pd.read_csv("data/df_req.csv")
df_vol = pd.read_csv("data/df_vol.csv")


st.sidebar.title("Меню")
menu_option = st.sidebar.radio("Выберите какие данные использовать", ["Предзагруженные данные", "Использовать свои данные"])



#---------- Меню выбора какие данные использовать ----------
if menu_option == "Использовать свои данные":
    st.sidebar.subheader("Загрузите необходимые файлы")
    
    files = st.sidebar.file_uploader("Загрузите свои файлы", type=["xlsx"], accept_multiple_files=True)
    
    for file in files:
      if file:
          try:
              df = pd.read_excel(file)
              st.session_state['data_loaded'] = True
              st.success("Файлы успешно загружены")
          except Exception as e:
              st.error(f"Ошибка при загрузке данных: {e}")

elif menu_option == "Предзагруженные данные":
    st.session_state['data_loaded'] = True
    st.success("Используем предзагруженные данные")
#---------- Конец меню выбора ----------



if st.session_state['data_loaded']:
    st.header("Основной блок с данными")
    st.write("Выберите по какой характеристике фильтровать данные")
    
    filter_choice = st.radio("Выберите фильтр:", ["Регион", "Без фильтра", "ID"])
    

    if filter_choice == "ID":
        id_input = st.number_input("Введите ID компании", min_value=1, max_value=21729, step=1, value=predict_df["ID"].unique()[0])
        id_filter = [id_input]
        region_filter = None
    elif filter_choice == "Регион":
        region_filter = st.selectbox("Выберите регион", predict_df["Регион"].unique())
        id_filter = None
    else:
        id_filter = None
        region_filter = None    


    filtered_df = predict_df
    if id_filter:
        filtered_df = filtered_df[filtered_df['ID'].isin(id_filter)]
    elif region_filter:
        filtered_df = filtered_df[filtered_df['Регион'] == region_filter]
    

    st.write("Данные из исходныхпо фильтру", filtered_df)
    

    st.header("Аналитика и данные от модели")
    
    # ЗДЕСЬ КОД ПО АНАЛИТИКЕ ОТ СЕМЫ
    st.subheader("Аналитика по данным")
    if id_filter != None:
        st.plotly_chart(plot_client_n_day_interactions(client_id=id_filter[0], df=df_interest))
        st.plotly_chart(plot_client_monthly_shipments(client_id=id_filter[0], df=df_price))
        st.plotly_chart(plot_client_monthly_volumes(client_id=id_filter[0], df=df_vol))
    elif region_filter != None:
        st.plotly_chart(plot_price_statistics(df=df_price, region=[region_filter]))
        st.plotly_chart(plot_volume_statistics(df=df_vol, region=[region_filter]))
    else:
        st.plotly_chart(plot_price_statistics(df=df_price, region=predict_df["Регион"].unique()))
        st.plotly_chart(plot_volume_statistics(df=df_vol, region=predict_df["Регион"].unique()))
    

    # ЗДЕСЬ КОД ПО МОДЕЛИ ОТ ВАНЕЧКА
    if id_filter is not None:
        filtered_predict = predict_df[predict_df["ID"].isin(id_filter)]
    elif region_filter is not None:
        filtered_predict = predict_df[predict_df["Регион"] == region_filter]
    else:
        filtered_predict = predict_df

    st.subheader("Предикт модели")
    if not filtered_predict.empty:
        filtered_predict = filtered_predict.sort_values(by="Вероятность")[::-1]

        st.table(filtered_predict.head(20))
        if filtered_predict.shape[0] > 10:
            fig = px.histogram(
                filtered_predict,
                x='Вероятность',
                nbins=100,
                title="Распределение вероятностей",
                color_discrete_sequence=["#636EFA"],
                marginal = 'box',
                labels={'Value': 'Вероятность ухода клиентов', 'count': 'Кол-во клиентов'}
            )
            fig.update_traces(marker_line_width=1, marker_line_color="black")
            st.plotly_chart(fig)
        
        st.download_button(
            label="Скачать датасет с вероятностями",
            data=filtered_predict.to_csv().encode("utf-8"),
            file_name='predict.csv',
            mime='text/csv'
        )
    else:
        st.write("Невозможно сделать предикт по данным с указанным фильтром")
else:
    st.warning("Пожалуйста загрузите файлы или выберите предзагруженные, чтобы продолжить.")