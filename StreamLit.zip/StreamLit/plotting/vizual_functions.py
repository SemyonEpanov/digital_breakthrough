import pandas as pd
import plotly.graph_objects as go
from pandas import Timestamp
from datetime import datetime, timedelta
import numpy as np


def plot_client_n_day_interactions(client_id, df, n_days=60, interval_days=30):
    """
    Строит график взаимодействий клиента c поддержкой за n дней с заданным интервалом.
    """

    bad_statuses = ['Завершен неудачно', 'Отказ в работе']
    good_statuses = ['Завершен успешно', 'Привлечение на "РЖД Маркет"', 'Коммерческое предложение',
                   'Заключение договора', 'Заказ оформлен', 'Готов к оказанию услуг',
                   'Проведение переговоров', 'Подключение тарифа', 'Анализ клиента',
                   'Регистрация клиента на "РЖД Маркет"', 'Раз. предложения\\Офор.заказа на "РЖД Маркет"',
                   'Аккредитация на "РЖД Маркет"']

    # Фильтрация данных по ID клиента
    client_df = df[df['ID'] == client_id]

    # Преобразование столбца 'Дата' в datetime
    client_df['Дата'] = pd.to_datetime(client_df['Дата'])

    # Заданный диапазон дат
    start_range = pd.to_datetime('2022-03-15')
    end_range = pd.to_datetime('2024-09-19')
    client_df = client_df[(client_df['Дата'] >= start_range) & (client_df['Дата'] <= end_range)]



    # Генерация дат для точек на графике
    dates = []
    current_date = start_range
    while current_date <= end_range:
        dates.append(current_date)
        current_date += timedelta(days=interval_days)

    interactions_data = []
    hover_text = []
    marker_colors = []

    for date in dates:
        period_start = date - timedelta(days=n_days)
        period_end = date

        period_interactions = client_df[(client_df['Дата'] >= period_start) & (client_df['Дата'] < period_end)]

        interaction_count = len(period_interactions)
        interactions_data.append(interaction_count)

        # Подсчет хороших и плохих статусов для цвета маркера
        good_count = period_interactions[period_interactions['Состояние'].isin(good_statuses)].shape[0]
        bad_count = period_interactions[period_interactions['Состояние'].isin(bad_statuses)].shape[0]
        marker_colors.append('#87A386' if good_count >= bad_count else '#CBB299')

        # Формирование текста подсказки с информацией о теме, состоянии и сценарии
        text = f"{date.strftime('%Y-%m-%d')}: {interaction_count} взаимодействий за {n_days} дней<br>"
        for _, row in period_interactions.iterrows():
            status_color = "green" if row['Состояние'] in good_statuses else "red"
            text += f"- {row['Тема']} ({row['Сценарий']}): <span style='color:{status_color}'>{row['Состояние']}</span><br>"
        hover_text.append(text)

    interactions_df = pd.DataFrame({'Дата': dates, 'Количество': interactions_data})


    # Определение цвета линии
    line_color = []
    for i in range(1, len(interactions_df)):
        if interactions_df['Количество'].iloc[i] > interactions_df['Количество'].iloc[i - 1]:
            line_color.append('#87A386')
        else:
            line_color.append('#CBB299')


    # Создание графика
    fig = go.Figure()


    # Добавление точек на график с цветными маркерами
    fig.add_trace(go.Scatter(
        x=interactions_df['Дата'],
        y=interactions_df['Количество'],
        mode='lines+markers',
        line=dict(color='#DCD0C0'),  # Базовый цвет линии
        marker=dict(size=10, color=marker_colors, line=dict(width=2, color='#F0EAD2')),
        hovertext=hover_text,
        hoverinfo="text"
    ))


     # Добавление цветных сегментов линии
    for i in range(len(line_color)):
        fig.add_trace(go.Scatter(
            x=interactions_df['Дата'].iloc[i:i+2],
            y=interactions_df['Количество'].iloc[i:i+2],
            mode='lines',
            line=dict(color=line_color[i], width=3),
            showlegend=False
        ))


    # Настройка макета графика
    fig.update_layout(
        title=f'Взаимодействия клиента {client_id} за {n_days} дней (интервал {interval_days} дней)',
        xaxis_title='Дата',
        yaxis_title='Количество взаимодействий',
        plot_bgcolor='#F8F2EC',
        paper_bgcolor='#F8F2EC',
        font_family="Garamond",
        font_color="#5E503F",
        title_font_family="Garamond",
        title_font_color="#5E503F",
    )

    return fig
#################################
# fig = plot_client_n_day_interactions(client_id=14419, df=df_interest, n_days=30, interval_days=30)
# fig.show()
#################################

def plot_client_monthly_shipments(client_id, df, n_months=6, interval_months=1):
    """
    Строит график объема отгрузок клиента за n месяцев с заданным интервалом.
    """

    # Фильтрация данных по ID клиента
    client_df = df[df['ID'] == client_id].groupby(by="ID").agg('sum')

    # Получение списка месяцев
    months = pd.to_datetime(client_df.columns[5:], format='%Y/%m').to_series()
    
    # Генерация дат для точек на графике
    dates = []
    current_date = months.min()
    while current_date <= months.max():
        dates.append(current_date)
        current_date = current_date + pd.DateOffset(months=interval_months)


    shipments_data = []
    hover_text = []
    marker_colors = [] # Пока что не используется, но оставил для будущих модификаций

    for date in dates:
        period_start = date - pd.DateOffset(months=n_months)
        period_end = date
        
        # Выбор столбцов с данными за период
        period_columns = months[(months >= period_start) & (months < period_end)].dt.strftime('%Y/%m').tolist()
        
        # Суммирование отгрузок за период
        if period_columns: # Проверка на пустой список
            try:
                shipment_sum = client_df[period_columns].sum(axis=1).values[0]
            except IndexError: # Обработка случая, если данных для клиента нет
                shipment_sum = 0
        else:
            shipment_sum = 0
            
        shipments_data.append(shipment_sum)

        # Формирование текста подсказки
        text = f"{date.strftime('%Y-%m')}: {shipment_sum} отгрузок за {n_months} месяцев<br>"

        # Добавляем информацию о каждой отгрузке в подсказку (если нужно) -  адаптируйте под ваши данные
        try:
            for month in period_columns:
                text += f"- {month}: {client_df[month].values[0]}<br>"
        except:
            pass

        hover_text.append(text)

    shipments_df = pd.DataFrame({'Дата': dates, 'Количество': shipments_data})

    # Определение цвета линии (аналогично предыдущему коду)
    line_color = []
    for i in range(1, len(shipments_df)):
        if shipments_df['Количество'].iloc[i] > shipments_df['Количество'].iloc[i - 1]:
            line_color.append('#87A386')
        else:
            line_color.append('#CBB299')

    # Создание графика
    fig = go.Figure()

    # Добавление точек на график
    fig.add_trace(go.Scatter(
        x=shipments_df['Дата'],
        y=shipments_df['Количество'],
        mode='lines+markers',
        line=dict(color='#DCD0C0'),
        marker=dict(size=10, line=dict(width=2, color='#F0EAD2')),  # Можете добавить color=marker_colors, если нужно
        hovertext=hover_text,
        hoverinfo="text"
    ))

    # Добавление цветных сегментов линии
    for i in range(len(line_color)):
        fig.add_trace(go.Scatter(
            x=shipments_df['Дата'].iloc[i:i+2],
            y=shipments_df['Количество'].iloc[i:i+2],
            mode='lines',
            line=dict(color=line_color[i], width=3),
            showlegend=False
        ))

    # Настройка макета графика (аналогично предыдущему коду)
    fig.update_layout(
        title=f'Покупки клиента (в рублях) {client_id} (интервал {interval_months} месяцев)',
        xaxis_title='Дата',
        yaxis_title='Количество отгрузок',
        plot_bgcolor='#F8F2EC',
        paper_bgcolor='#F8F2EC',
        font_family="Garamond",
        font_color="#5E503F",
        title_font_family="Garamond",
        title_font_color="#5E503F",
    )

    return fig
########################
# plot_client_monthly_shipments(client_id=8733, df=df_price, n_months=1, interval_months=1)
########################

def plot_price_statistics(df, region):
    """
    Строит график моды, медианы и среднего для заданного региона по времени.
    """

    # Фильтрация данных по региону
    df_region = df[df['Субъект федерации наз'].isin(region)]
    
    # Преобразование данных: оставляем только столбцы с датами и ценами
    df_melted = df_region.melt(id_vars=['ID', 'Субъект федерации наз'], 
                               var_name='Дата', value_name='Цена')
    
    # Преобразование столбца с датой в формат datetime
    df_melted['Дата'] = pd.to_datetime(df_melted['Дата'], format='%Y/%m', errors='coerce')
    
    # Убираем строки с NaN в столбце 'Дата' и строки с нулевыми значениями цены
    df_melted = df_melted.dropna(subset=['Дата'])
    df_melted = df_melted[df_melted['Цена'] > 0]
    
    # Группируем по дате и рассчитываем среднее, медиану и моду
    grouped = df_melted.groupby('Дата').agg(
        Среднее=('Цена', 'mean'),
        Медиана=('Цена', 'median'),
        Мода=('Цена', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
    ).reset_index()

    # Создание графика с Plotly
    fig = go.Figure()

    # Линия для среднего
    fig.add_trace(go.Scatter(
        x=grouped['Дата'], 
        y=grouped['Среднее'], 
        mode='lines+markers', 
        name='Среднее', 
        line=dict(color='#87A386'),  # Цвет линии для среднего
        marker=dict(size=8, line=dict(width=2, color='#F0EAD2')),
        hovertext=[f"{d:%Y-%m}: Среднее = {v:.2f}" for d, v in zip(grouped['Дата'], grouped['Среднее'])],
        hoverinfo="text"
    ))

    # Линия для медианы
    fig.add_trace(go.Scatter(
        x=grouped['Дата'], 
        y=grouped['Медиана'], 
        mode='lines+markers', 
        name='Медиана', 
        line=dict(color='#CBB299'),  # Цвет линии для медианы
        marker=dict(size=8, line=dict(width=2, color='#F0EAD2')),
        hovertext=[f"{d:%Y-%m}: Медиана = {v:.2f}" for d, v in zip(grouped['Дата'], grouped['Медиана'])],
        hoverinfo="text"
    ))

    # Линия для моды
    fig.add_trace(go.Scatter(
        x=grouped['Дата'], 
        y=grouped['Мода'], 
        mode='lines+markers', 
        name='Мода', 
        line=dict(color='#DCD0C0'),  # Цвет линии для моды
        marker=dict(size=8, line=dict(width=2, color='#F0EAD2')),
        hovertext=[f"{d:%Y-%m}: Мода = {v:.2f}" for d, v in zip(grouped['Дата'], grouped['Мода'])],
        hoverinfo="text"
    ))

    # Настройка макета графика
    if len(region) == 1:
        region = region[0]
    else:
        region = "все регионы"
    fig.update_layout(
        title=f'Статистика для региона: {region}',
        xaxis_title='Дата',
        yaxis_title='Рублей',
        plot_bgcolor='#F8F2EC',
        paper_bgcolor='#F8F2EC',
        font_family="Garamond",
        font_color="#5E503F",
        title_font_family="Garamond",
        title_font_color="#5E503F",
        hovermode='x unified'
    )

    return fig
######################################
# Пример использования:
# fig = plot_price_statistics(df_price, 'Кировская область')
# fig.show()
######################################

def plot_client_monthly_volumes(client_id, df, n_months=6, interval_months=1):
    """
    Строит график объема отгрузок клиента за n месяцев с заданным интервалом.
    """

    # Фильтрация данных по ID клиента
    client_df = df[df['ID'] == client_id].groupby(by="ID").agg('sum')

    # Получение списка месяцев (столбцы начиная с 5-го)
    months = pd.to_datetime(client_df.columns[5:], format='%Y/%m').to_series()
    
    # Генерация дат для точек на графике
    dates = []
    current_date = months.min()
    while current_date <= months.max():
        dates.append(current_date)
        current_date = current_date + pd.DateOffset(months=interval_months)

    volumes_data = []
    hover_text = []

    for date in dates:
        period_start = date - pd.DateOffset(months=n_months)
        period_end = date
        
        # Выбор столбцов с данными за период
        period_columns = months[(months >= period_start) & (months < period_end)].dt.strftime('%Y/%m').tolist()
        
        # Суммирование объемов за период
        if period_columns:  # Проверка на пустой список столбцов
            try:
                volume_sum = client_df[period_columns].sum(axis=1).values[0]
            except IndexError:  # Обработка случая, если данных для клиента нет
                volume_sum = 0
        else:
            volume_sum = 0
            
        volumes_data.append(volume_sum)

        # Формирование текста подсказки для всплывающих окон
        text = f"{date.strftime('%Y-%m')}: {volume_sum} объема за {n_months} месяцев<br>"

        # Добавляем информацию о каждом месяце в подсказку
        for month in period_columns:
            text += f"- {month}: {client_df[month].values[0]}<br>"

        hover_text.append(text)

    volumes_df = pd.DataFrame({'Дата': dates, 'Объем': volumes_data})

    # Создание графика
    fig = go.Figure()

    # Добавление точек на график
    fig.add_trace(go.Scatter(
        x=volumes_df['Дата'],
        y=volumes_df['Объем'],
        mode='lines+markers',
        line=dict(color='#DCD0C0'),
        marker=dict(size=10, line=dict(width=2, color='#F0EAD2')), 
        hovertext=hover_text,
        hoverinfo="text"
    ))

    # Настройка макета графика
    fig.update_layout(
        title=f'Объем отгрузок клиента {client_id} (интервал {interval_months} месяцев)',
        xaxis_title='Дата',
        yaxis_title='Объем отгрузок',
        plot_bgcolor='#F8F2EC',
        paper_bgcolor='#F8F2EC',
        font_family="Garamond",
        font_color="#5E503F",
        title_font_family="Garamond",
        title_font_color="#5E503F",
    )

    return fig
#########################
# Пример использования:
# fig = plot_client_monthly_volumes(client_id=912, df=df_vol, n_months=2, interval_months=1)
# fig.show()
###################################



def plot_volume_statistics(df, region):
    """
    Строит график моды, медианы и среднего объема для заданного региона по времени.
    """

    # Фильтрация данных по региону
    df_region = df[df['Субъект федерации наз'].isin(region)]

    # Преобразование данных: оставляем только столбцы с датами и объемами
    df_melted = df_region.melt(id_vars=['ID', 'Субъект федерации наз'], 
                               var_name='Дата', value_name='Объем')

    # Преобразование столбца с датой в формат datetime
    df_melted['Дата'] = pd.to_datetime(df_melted['Дата'], format='%Y/%m', errors='coerce')

    # Убираем строки с NaN в столбце 'Дата' и строки с нулевыми значениями объема
    df_melted = df_melted.dropna(subset=['Дата'])
    df_melted = df_melted[df_melted['Объем'] > 0]

    # Группируем по дате и рассчитываем среднее, медиану и моду
    grouped = df_melted.groupby('Дата').agg(
        Среднее=('Объем', 'mean'),
        Медиана=('Объем', 'median'),
        Мода=('Объем', lambda x: x.mode()[0] if not x.mode().empty else np.nan)
    ).reset_index()

    # Создание графика с Plotly
    fig = go.Figure()

    # Линия для среднего
    fig.add_trace(go.Scatter(
        x=grouped['Дата'], 
        y=grouped['Среднее'], 
        mode='lines+markers', 
        name='Среднее', 
        line=dict(color='#87A386'),  # Цвет линии для среднего
        marker=dict(size=8, line=dict(width=2, color='#F0EAD2')),
        hovertext=[f"{d:%Y-%m}: Среднее = {v:.2f}" for d, v in zip(grouped['Дата'], grouped['Среднее'])],
        hoverinfo="text"
    ))

    # Линия для медианы
    fig.add_trace(go.Scatter(
        x=grouped['Дата'], 
        y=grouped['Медиана'], 
        mode='lines+markers', 
        name='Медиана', 
        line=dict(color='#CBB299'),  # Цвет линии для медианы
        marker=dict(size=8, line=dict(width=2, color='#F0EAD2')),
        hovertext=[f"{d:%Y-%m}: Медиана = {v:.2f}" for d, v in zip(grouped['Дата'], grouped['Медиана'])],
        hoverinfo="text"
    ))

    # Линия для моды
    fig.add_trace(go.Scatter(
        x=grouped['Дата'], 
        y=grouped['Мода'], 
        mode='lines+markers', 
        name='Мода', 
        line=dict(color='#DCD0C0'),  # Цвет линии для моды
        marker=dict(size=8, line=dict(width=2, color='#F0EAD2')),
        hovertext=[f"{d:%Y-%m}: Мода = {v:.2f}" for d, v in zip(grouped['Дата'], grouped['Мода'])],
        hoverinfo="text"
    ))

    # Настройка макета графика
    if len(region) == 1:
        region = region[0]
    else:
        region = "все регионы"
    fig.update_layout(
        title=f'Статистика объема для региона: {region}',
        xaxis_title='Дата',
        yaxis_title='Объем (тонны)',
        plot_bgcolor='#F8F2EC',
        paper_bgcolor='#F8F2EC',
        font_family="Garamond",
        font_color="#5E503F",
        title_font_family="Garamond",
        title_font_color="#5E503F",
        hovermode='x unified'
    )

    return fig
####################################
# Пример использования:
# fig = plot_volume_statistics(df_vol, 'Кировская область')
# fig.show()
####################################